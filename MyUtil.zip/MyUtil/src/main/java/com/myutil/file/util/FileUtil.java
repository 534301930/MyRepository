package com.myutil.file.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class FileUtil {

	/**
	 * 复制文件或文件夹
	 * @param fromFile 从哪个文件对象
	 * @param toFile 到哪个文件对象
	 * @param overWrite 是否覆盖
	 */
	public static boolean copy(File fromFile, File toFile, boolean overWrite) {
		try {
			// 若文件不存在，抛出异常
			if (!fromFile.exists()) {
				throw new FileNotFoundException("该文件不存在，请检查一下路径：" + fromFile.getPath());
			}
			// 若文件对象为文件则进行复制操作
			if (fromFile.isFile()) {
				copyFile(fromFile, toFile, overWrite);
			} else {// 文件对象为文件夹
				// 若目标文件夹对象不存在，则创建目标文件夹
				if (!toFile.exists()) {
					toFile.mkdir();
				}
				// 循环子文件夹
				File[] files = fromFile.listFiles();
				for (File file : files) {
					// 递归
					copyFile(file, new File(toFile.getPath() + "/" + file.getName()), overWrite);
				}
			}
			return true;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return false;
	}

	private static void copyFile(File fromFile, File toFile, boolean overWrite) {
		try {
			// 目标文件已经存在
			if (toFile.exists()) {
				if (overWrite) {// 替换文件
					if (!toFile.delete()) {// 如果文件删除失败
						throw new RuntimeException(toFile.getPath() + "无法覆盖!");
					}
				} else {// 不允许覆盖
					return;
				}
			}
			// 目标文件不存在
			InputStream in = new FileInputStream(fromFile);
			OutputStream out = new FileOutputStream(toFile);
			byte[] buffer = new byte[1024];
			int read = 0;
			while ((in.read(buffer)) != -1) {
				out.write(buffer, 0, read);
			}
			out.flush();
			out.close();
			in.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void delete(File file) {
		deleteFile(file);
	}

	private static void deleteFile(File file) {
		// 若文件不存在
		if (file == null || !file.exists()) {
			return;
		}
		// 单个文件
		if (!file.isDirectory()) {
			boolean delete = file.delete();
			if (!delete) {
				throw new RuntimeException(file.getPath() + "删除失败！");
			} else {
				return;
			}
		}
		// 删除目录
		// 删除子目录
		File[] children = file.listFiles();
		for (File child : children) {
			// 递归
			delete(child);
		}
	}
	
	public static void save(byte[] content, File file) throws IOException {
        if (file == null) {
            throw new RuntimeException("保存文件不能为空");
        }
        if (content == null) {
            throw new RuntimeException("文件流不能为空");
        }
        InputStream is = new ByteArrayInputStream(content);
        save(is, file);
    }
	
	public static void save(InputStream streamIn, File file) throws IOException {
        if (file == null) {
            throw new RuntimeException("保存文件不能为空");
        }
        if (streamIn == null) {
            throw new RuntimeException("文件流不能为空");
        }
        // 输出流
        OutputStream streamOut = null;
        // 文件夹不存在就创建。
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
        streamOut = new FileOutputStream(file);
        int bytesRead = 0;
        byte[] buffer = new byte[8192];
        while ((bytesRead = streamIn.read(buffer, 0, 8192)) != -1) {
            streamOut.write(buffer, 0, bytesRead);
        }
        streamOut.close();
        streamIn.close();
    }
}
