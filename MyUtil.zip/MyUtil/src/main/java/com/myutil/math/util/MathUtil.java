package com.myutil.math.util;

public class MathUtil {

	public static final double PI = Math.PI;

	/**
	 * 从a到b中去随机整数
	 * @param a
	 * @param b
	 * @return
	 */
	public int getRandom(int a, int b) {
		if (a < b) {
			return (int) (a + Math.random() * (b - a));
		} else if (a == b) {
			return a;
		} else {
			return getRandom(b, a);
		}
	}
}
