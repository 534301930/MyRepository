package com.myutil.httpclient.model;

import org.json.JSONObject;

public class Head {

	private String code;
	private String msg;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	/**
	 * 加载配置
	 * @param head json对象
	 */
	public void applyMappings(JSONObject head) {
		try {
			this.code = head.getString("code");
			this.msg = head.getString("msg");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

}
