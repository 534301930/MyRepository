package com.myutil.httpclient.model;

import org.json.JSONException;
import org.json.JSONObject;

public class HeadAndDataMessage extends BaseMessage {

	private Head head;// 消息头

	public Head getHead() {
		return head;
	}

	public void setHead(Head head) {
		this.head = head;
	}
	
	/**
	 * 加载配置
	 */
	@Override
	public void applyMappings(JSONObject jsonObject) {
		try {
			JSONObject head = jsonObject.getJSONObject("head");
			this.head.applyMappings(head);
			super.applyMappings(jsonObject.getJSONObject("data"));
		} catch (JSONException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * 加载配置
	 */
	@Override
	public void applyMappings(Object bean) {
		if (bean == null || bean.equals(new Object())) {
			return;
		}
		JSONObject jsonObject = new JSONObject(bean);
		this.applyMappings(jsonObject);
	}
	
	/**
	 * 加载配置
	 */
	@Override
	public void applyMappings(String jsonStr) {
		if (jsonStr == null || jsonStr.equals("")) {
			return;
		}
		JSONObject jsonObject = new JSONObject(jsonStr);
		this.applyMappings(jsonObject);
	}
	
	/**
	 * 返回json字符串
	 */
	@Override
	public String toJsonStr() {
		return new JSONObject(this).toString();
	}
}
