package com.myutil.httpclient.model;

import org.json.JSONObject;

/**
 * 基础消息体
 * @author lee
 *
 */
public class BaseMessage {

	protected JSONObject data;// 数据

	public JSONObject getData() {
		return data;
	}

	public void setData(JSONObject data) {
		this.data = data;
	}

	public void applyMappings(JSONObject data) {
		this.data = data;
	}
	
	/**
	 * 加载属性
	 * @param jsonStr json字符串
	 */
	public void applyMappings(String jsonStr) {
		try {
			if (jsonStr == null || jsonStr.equals("")) {
				return;
			}
			this.data = new JSONObject(jsonStr);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * 加载属性
	 * @param bean javabean
	 */
	public void applyMappings(Object bean) {
		try {
			if (bean == null) {
				return;
			}
			this.data = new JSONObject(bean);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * 加载属性
	 * @return json字符串
	 */
	public String toJsonStr() {
		return new JSONObject(this).toString();
	}
}
