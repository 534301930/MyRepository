package com.myutil.httpclient.util;

import java.io.IOException;
import java.nio.charset.Charset;

import org.apache.http.HttpEntity;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import com.myutil.httpclient.model.BaseMessage;

public class HttpClientUtil {

	/**
	 * post方式发送请求
	 * @param url:请求地址
	 * @param message:消息体
	 * @return 响应信息，字符串形式，可能为null
	 */
	public String post(String url, BaseMessage message) {
		CloseableHttpClient httpClient;
		HttpPost httpPost;
		CloseableHttpResponse httpResponse;
		HttpEntity entity;
		String s = null;
		try {
			httpClient = HttpClientBuilder.create().build();
			httpPost = new HttpPost(url);
			httpPost.setEntity(new StringEntity(message.toJsonStr(), Charset.forName("UTF-8")));
			httpResponse = httpClient.execute(httpPost);
			entity = httpResponse.getEntity();
			s = EntityUtils.toString(entity);
			httpPost.releaseConnection();
			httpClient.close();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return s;
	}
	
	/**
	 * get方式发送请求
	 * @param url:请求地址
	 * @return 响应信息，字符串形式，可能为null
	 */
	public String get(String url) {
		CloseableHttpClient httpClient;
		HttpGet httpGet;
		CloseableHttpResponse httpResponse;
		HttpEntity entity;
		String s = null;
		try {
			httpClient = HttpClientBuilder.create().build();
			httpGet = new HttpGet(url);
			httpResponse = httpClient.execute(httpGet);
			entity = httpResponse.getEntity();
			s = EntityUtils.toString(entity);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return s;
	}
}
