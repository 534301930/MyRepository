package com.myutil.collection.list;


public class LinkedList<T> implements List<T> {

	private int size;// 容量
	private Node<T> cursor;// 指针
	private Node<T> root;// 链表

	public LinkedList() {
		this.size = 0;
		this.root = new Node<T>();
	}

	public boolean add(T t) {
		try {
			if (this.root.getData() == null) {// 添加第一个数据
				this.root.setData(t);
				this.cursor = this.root;
			} else {
				Node<T> currentNode = this.root;
				if (currentNode.getNext() == null) {
					Node<T> node = new Node<T>();
					node.setData(t);
					this.root.setNext(node);
					this.cursor = currentNode.getNext();
				} else {// 跳到这一步，cursor一定是最后一个节点
					currentNode = this.cursor;
					Node<T> node = new Node<T>();
					node.setData(t);
					currentNode.setNext(node);
					this.cursor = currentNode.getNext();
				}
			}
			this.size++;
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public T get(int index) {
		Node<T> currentNode;
		if (index == 0) {
			currentNode = this.root;
		} else if (index < this.size - 1) {
			currentNode = this.root.getNext();
			for (int i = 0; i < index - 1; i++) {
				currentNode = currentNode.getNext();
			}
		} else {
			throw new IndexOutOfBoundsException("size : " + size + ", index : "
					+ index);
		}
		return currentNode.getData();
	}

	@Override
	public int size() {
		return this.size;
	}
	
	public LinkedListIterator<T> iterator() {
		return new LinkedListIterator<T>(this);
	}

	@SuppressWarnings("hiding")
	private class LinkedListIterator<T> implements Iteratable<T> {

		private boolean hasNext;
		private Node<T> cursor;
		private Node<T> root;

		public LinkedListIterator(LinkedList<T> linkedList) {
			this.root = linkedList.root;
			this.cursor = this.root;
			this.hasNext = true;
		}

		public boolean hasNext() {
			return this.hasNext;
		}

		public T next() {
			Node<T> node = cursor;
			iterate(node);
			return node.getData();
		}

		private void iterate(Node<T> node) {
			if (node.getNext() == null) {
				this.hasNext = false;
				this.cursor = null;
			} else {
				this.hasNext = true;
				this.cursor = node.getNext();
			}
		}

	}

}

class Node<T> {

	private T data;
	private Node<T> next;

	protected T getData() {
		return data;
	}

	protected void setData(T data) {
		this.data = data;
	}

	protected Node<T> getNext() {
		return next;
	}

	protected void setNext(Node<T> next) {
		this.next = next;
	}

}
