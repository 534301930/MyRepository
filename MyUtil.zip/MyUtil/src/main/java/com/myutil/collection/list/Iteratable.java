package com.myutil.collection.list;

public interface Iteratable<T> {
	
	public boolean hasNext();

	public T next();
}
