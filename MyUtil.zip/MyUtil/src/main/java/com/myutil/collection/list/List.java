package com.myutil.collection.list;


public interface List<T> {
	
	public boolean add(T t);

	public T get(int index);
	
	public Iteratable<T> iterator();

	public int size();
}
