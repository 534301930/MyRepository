package com.myutil.collection.list;

public class ArrayList<T> implements List<T> {

	private Object[] array;// 容器
	private int size;// 标记
	private int capacity = 16;// 初始和可增容量

	public ArrayList() {
		array = new Object[capacity];
		size = 0;
	}

	public boolean add(T t) {
		return addElement(t);
	}

	private boolean addElement(T t) {
		try {
			if (size < 16) {
				array[size++] = t;
				return true;
			} else {
				capacity += 16;
				return addElement(t);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	public T get(int index) {
		try {
			return (T) array[index];
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int size() {
		return this.size;
	}

	public ArrayListIterator<T> iterator() {
		return new ArrayListIterator<T>(this);
	}

	@Override
	public String toString() {
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append("[");
		ArrayListIterator<T> iterator = this.iterator();
		while (iterator.hasNext()) {
			T next = iterator.next();
			stringBuffer.append(next);
			stringBuffer.append(", ");
		}
		stringBuffer.delete(stringBuffer.length() - 2, stringBuffer.length());
		stringBuffer.append("]");
		return stringBuffer.toString();
	}
	
	@SuppressWarnings("hiding")
	private class ArrayListIterator<T> implements Iteratable<T> {

		private T next;// 下一个元素
		private boolean hasNext;// 是否有下一个元素
		private ArrayList<T> arrayList;// 集合
		private int cursor = 0;// 游标

		public ArrayListIterator(ArrayList<T> arrayList) {
			this.arrayList = arrayList;
			iterate();
		}

		public boolean hasNext() {
			return hasNext;
		}
		
		public T next() {
			T next = this.next;
			cursor++;
			iterate();
			return next;
		}

		private void iterate() {
			if (this.arrayList.size > cursor) {// 有元素
				this.hasNext = true;
				this.next = (T) this.arrayList.get(cursor);
			} else {
				this.hasNext = false;
				this.next = null;
			}
		}
	}
}