package com.myutil.collection.util;

import com.myutil.collection.list.List;

public class CollectionUtil {

	public static int[] IntegerListToIntArray(List<Integer> list) {
		int[] intArray = new int[list.size()];
		for (int i = 0; i < list.size(); i++) {
			intArray[i] = list.get(i);
		}
		return intArray;
	}
	
}
