package com.myutil.string.util;


public class StringUtil {

	/**
	 * 判断null或空值
	 * @return
	 */
	public static boolean isNullOrEmpty(String s) {
		return s == null || s.equals("");
	}
	
}
