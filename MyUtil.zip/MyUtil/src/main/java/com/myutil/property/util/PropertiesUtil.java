package com.myutil.property.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.myutil.string.util.StringUtil;

public class PropertiesUtil {

	private List<Properties> propertiesList = new ArrayList<Properties>();
	private List<String> propertiesLocationsList = new ArrayList<String>();
	
	public PropertiesUtil() {
		initPropertiesList();
	}
	
	/**
	 * 初始化properties列表
	 */
	private void initPropertiesList() {
		Properties config = new Properties();
		try {
			try {
				config.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("myUtil.properties"));
			} catch (Exception e1) {
				throw new RuntimeException("在类路径下找不到 myUtil.properties 文件");
			}
			// 1. 获取propertiesLocation
			String propertiesLocation = null;
			try {
				propertiesLocation = config.getProperty("propertiesLcation").replaceAll("\\\\", "/");
			} catch (Exception e) {
				throw new RuntimeException("myUtil.properties中没有\"propertiesLocation\"属性！");
			}
			if (propertiesLocation.equals("")) {
				throw new RuntimeException("myUtil.properties中没有初始化\"propertiesLocation\"属性");
			}
			// 2. 获取locationType[absolute, relative]
			String locationType = null;
			try {
				locationType = config.getProperty("locationType");
			} catch (Exception e) {
				throw new RuntimeException("myUtil.properties中没有\"locationType\"属性！");
			}
			if (locationType.equals("")) {
				throw new RuntimeException("myUtil.properties中没有初始化\"locationType\"属性");
			}
			// 3. 如果是绝对路径，则获取项目根路径，进行处理
			if (locationType.equals("absolute")) {
				String rootPath = new File("").getCanonicalPath().replaceAll("\\\\", "/");
				propertiesLocation = rootPath + propertiesLocation;
			}
			// 4. 如果是相对路径
			if (locationType.equals("relative")) {
				// 4.1 如果以classpath:开头，则做相应处理
				if (propertiesLocation.startsWith("classpath:")) {
					propertiesLocation = propertiesLocation.replace("classpath:", "");
				}
				// 4.2 将相对路径转换成绝对路径
				propertiesLocation = ClassLoader.getSystemResource("").getPath().replaceAll("\\\\", "/") + propertiesLocation;
			} else {
				throw new RuntimeException("myUtil.properties文件中，\"locationType\"配置的属性不合法，属性值为：\"absolute\"或\"relative\"！");
			}
			doinit(propertiesLocation);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 初始化properties列表实现细节
	 * @param propertiesLocation 绝对路径
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	private void doinit(String propertiesLocation) throws FileNotFoundException, IOException {
		// 5. 如果路径中存在*
		if (propertiesLocation.contains("*")) {
			// 5.1 如果为classpath:.../xxx*xxx/.../xxx.properties形式
			if (propertiesLocation.matches(".*\\*.*/.*")) {
				File parentDirectory = getParentDirectory(propertiesLocation);
				File[] files = parentDirectory.listFiles();
				// 5.1.2 取得该父目录下所有子文件夹
				List<File> childrenDirectories = new ArrayList<File>();
				for (File file : files) {
					if (file.isDirectory()) {
						childrenDirectories.add(file);
					}
				}
				// 5.1.3 进行递归操作
				int star_index = propertiesLocation.indexOf("*");
				String suffix = null;
				for (int i = star_index + 1; i < propertiesLocation.length(); i++) {
					if (propertiesLocation.charAt(i) == '/') {
						suffix = propertiesLocation.substring(i);
						break;
					}
				}
				for (File file : childrenDirectories) {
					doinit(file.getAbsolutePath().replaceAll("\\\\", "/") + suffix);
				}
				return;
			}
			// 5.2 如果为classpath:.../xxx*xxx.properties形式
			if (propertiesLocation.matches(".*\\*.*\\.properties")) {
				// 5.2.1 获取上一级目录，遍历该目录下所有子文件
				File parentDirectory = getParentDirectory(propertiesLocation);
				File[] childFiles = parentDirectory.listFiles();
				// 5.2.2 将父目录下的ant表达式，转换成相应的正则表达式，即开头加^，结尾加$，中间的*用.*替代
				String ant_str = propertiesLocation.replace(parentDirectory.getAbsolutePath().replaceAll("\\\\", "/") + "/", "");
				if (ant_str.startsWith("/")) {
					ant_str = ant_str.replaceFirst("/", "");
				}
				String matches = "^" + ant_str.replace("*", ".*") + "$";
				// 遍历文件，只要找到相匹配的文件，加入到properties文件列表中
				for (File file : childFiles) {
					String name = file.getName();
					if (name.matches(matches)) {
						Properties properties = new Properties();
						properties.load(new FileReader(file));
						propertiesList.add(properties);
						propertiesLocationsList.add(file.getAbsolutePath().replaceAll("\\\\", "/"));
					}
				}
			}
		}
	}

	/**
	 * 获取*所在地址的父目录
	 * @param propertiesLocation
	 * @return
	 */
	private File getParentDirectory(String propertiesLocation) {
		// 查找*的索引
		int star_index = propertiesLocation.indexOf("*");
		String parentPath = null;
		// 查找*之前最近的“/”的索引，获取父目录地址
		for (int i = star_index - 1; i > -1; i--) {
			if (propertiesLocation.charAt(i) == '/') {
				parentPath = propertiesLocation.substring(0, i);
				break;
			}
		}
		File parentDirectory = new File(parentPath);
		return parentDirectory;
	}

	/**
	 * 获取property文件中的属性
	 * @param pathname
	 * @param key
	 * @return
	 */
	public String getProperty(String key) {
		try {
			String value = null;
			Properties currentProperties = null;
			for (Properties properties : propertiesList) {
				if (properties.containsKey(key)) {
					value = properties.getProperty(key);
					currentProperties = properties;
					break;
				}
			}
			if (StringUtil.isNullOrEmpty(value)) {
				throw new RuntimeException(key + "属性在properties列表中的配置有问题：未初始化或没有\""+ key +"\"属性！");
			}
			return replaceExpressionWithValue(currentProperties, key, value);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 从给定的properties中获取K-V
	 * @param currentProperties
	 * @param key
	 * @return
	 */
	private String getProperty(Properties currentProperties, String key) {
		try {
			String property = null;
			if (currentProperties.containsKey(key)) {
				property = currentProperties.getProperty(key);
			} else {
				property = getProperty(key);// 在当前文件中没有该属性值得情况下，从其他文件中寻找该属性
			}
			if (StringUtil.isNullOrEmpty(property)) {
				int index = 0;
				String propertiesPath = null;
				for (Properties properties : propertiesList) {
					if (properties == currentProperties) {
						propertiesPath = propertiesLocationsList.get(index);
						break;
					}
					index++;
				}
				if (StringUtil.isNullOrEmpty(propertiesPath)) {
					propertiesPath = "properties列表";
				}
				throw new RuntimeException(key + "属性在"+ propertiesPath +"中的配置有问题：未初始化或没有"+ key +"属性！");
			}
			return replaceExpressionWithValue(currentProperties, key, property);
		} catch (RuntimeException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 将表达式替换成相应的值
	 * @param currentProperties : 文件的路径
	 * @param key
	 * @param value
	 * @return
	 * @throws Exception
	 */
	private String replaceExpressionWithValue(Properties currentProperties,
			String key, String value) throws Exception {
		if (StringUtil.isNullOrEmpty(value)) {
			throw new Exception("取到的值为null或空字符串！key : " + key);
		}
		// 1.若值中存在${}表达式，则进行替换
		if (value.matches(".*\\$\\{.*\\}.*")) {
			int _$, _a, _b = 0, index = 0;
			do {
				// 1.1 查找$的下一个索引位置，若不小于0，则继续循环
				_$ = value.indexOf("$", index == 0 ? index : index + 1);
				if (_$ < 0) {
					break;
				}
				index = _$;
				// 1.2查找紧跟之后的{的索引位置，若符合情况，则继续循环，否则，跳过本次循环，直接进行下一次循环
				if (value.charAt(_$ + 1) == '{') {
					_a = _$ + 1;
				} else {
					continue;
				}
				// 1.3查找}的索引位置，且{和}之间没有“$”或“{”出现，否则抛出异常
				for (int i = _a; i < value.length(); i++) {
					char c = value.charAt(i);
					if ((c == '$' || c == '{') && i != _a) {
						throw new Exception("properties属性中表达式引用有误： “${” 和 “}” 之间存在 “$” 或 “{” ！key : " + key);
					}
					if (c == '}') {// 若找到}，则记录索引位置，退出循环
						_b = i;
						break;
					}
					if (c != '}' && i == value.length() - 1) {
						throw new Exception("properties属性中表达式引用有误：缺失 “}” ！key : " + key);
					}
				}
				// 1.4获取表达式
				String expression = value.substring(_a + 1, _b);
				// 1.5查找该表达式对应的值，进行替换
				String replace = this.getProperty(currentProperties, expression);
				value = value.replaceAll("\\$\\{" + expression + "\\}", replace);
			} while (index + 1 < value.length());
			return value;
		}
		// 2.若不存在，正常返回
		else {
			return value;
		}
	}
	
	public static void main(String[] args) throws Exception {
		String property = new PropertiesUtil().getProperty("testa");
		System.out.println(property);
//		System.out.println("few/*/*.properties".matches(".*\\*.*/.*"));
	}
}
