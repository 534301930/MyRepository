package com.myutil.property.util;

import java.util.Properties;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

public class CustomizePropertyPlaceHolder extends PropertyPlaceholderConfigurer {

	private Properties properties = null;
	
	/**
	 * 重写处理属性文件的方法
	 */
	@Override
	protected void processProperties(
			ConfigurableListableBeanFactory beanFactoryToProcess,
			Properties props) throws BeansException {
		// 执行父类处理读取文件
		super.processProperties(beanFactoryToProcess, props);
		// 存储属性文件的引用
		properties = props;
	}
	
	/**
	 * 根据属性文件中的键值获取对应属性文件中的值
	 * @param key
	 * @return
	 */
	public String getProperty(String key) {
		return properties.getProperty(key);
	}
}
