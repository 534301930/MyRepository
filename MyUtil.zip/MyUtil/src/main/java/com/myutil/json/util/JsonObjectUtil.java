package com.myutil.json.util;

import org.json.JSONException;
import org.json.JSONObject;

public class JsonObjectUtil {

	/**
	 * 根据传入的键值对顺序组装成jsonObject
	 * @param params
	 * @return
	 */
	public static JSONObject makeJsonObject(Object... params) {
		if (!(params.length % 2 == 0)) {// 参数的个数为奇数
			throw new JSONException("键值对不匹配！存在单独的键或值");
		} else {
			JSONObject object = new JSONObject();
			int index = 0;
			while (index < params.length) {
				String key = (String) params[index++];
				Object value = params[index++];
				object.put(key, value);
			}
			return object;
		}
	}

	public static void main(String[] args) {
		JSONObject object = makeJsonObject("flag", false, "msg", "error!");
		System.out.println(object.toString());
	}
}
